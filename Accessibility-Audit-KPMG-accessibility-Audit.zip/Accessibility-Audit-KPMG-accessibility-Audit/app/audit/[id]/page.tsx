'use client';
import { useState, useEffect, useCallback, useRef } from 'react';
import { useParams } from 'next/navigation';

// ===== TYPE INTERFACES =====
interface AuditData {
  id: string; status: string; progress: number; progressMessage: string;
  config: { url?: string; type: string; wcagLevels?: string[]; standard?: string };
  pages: { url: string; title: string }[];
  issues: Issue[]; score: Score; report?: Report; crawlCoverage?: CrawlCoverage;
  testResults: TestResultItem[]; testLog: TestLogEntry[];
  inapplicableCriteria?: string[];
  error?: string;
}
interface Issue {
  id: string; testId: string; title: string; description: string;
  element: string; elementHtml?: string; pageUrl: string;
  wcagCriterion: string; wcagName: string; wcagLevel: string;
  severity: string; impact: string; recommendation: string;
  codeFix?: string; category: string; source: string; confidence?: string;
}
interface Score {
  overall: number; categoryScores: Record<string, number>;
  complianceLevel: string; totalIssues: number; uniqueIssues?: number;
  issueBySeverity: Record<string, number>; issueByLevel: Record<string, number>;
  journeyScore?: number; testsRun: number; testsPassed: number; testsFailed: number;
}
interface TestResultItem {
  testId: string; testName: string; pageUrl: string; status: string;
  wcagCriterion: string; wcagName: string; wcagLevel: string;
  severity: string; confidence: string;
  evidence: { summary: string; elementsChecked: number; elementsFailed: number; details: string[] };
  issues: Issue[]; executionTime: number; error?: string;
}
interface TestLogEntry {
  timestamp: string; testId: string; testName: string; wcag: string;
  status: string; message: string; pageUrl?: string;
}
interface GroupedIssue {
  issueKey: string; title: string; testId: string;
  wcagCriterion: string; wcagName: string; wcagLevel: string;
  severity: string; category: string; description: string;
  recommendation: string; codeFix?: string; confidence: string;
  occurrenceCount: number; affectedPages: string[]; frequency: number;
}
interface JourneyResult {
  journeyName: string; description: string;
  steps: { name: string; action: string; passed: boolean; issue?: string }[];
  passed: boolean;
}
interface CrawlCoverage {
  totalPagesFound: number; pagesAudited: number; pagesSkipped: number;
  coveragePercent: number; skippedPages: { url: string; reason: string }[];
  discoveryMethods: Record<string, number>;
}
interface Report {
  testedLevel?: string;
  executiveSummary: string; groupedIssues?: GroupedIssue[]; topCritical?: GroupedIssue[];
  journeyResults?: JourneyResult[]; testResults?: TestResultItem[];
  wcagMapping: { criterion: string; name: string; level: string; issueCount: number; status: string }[];
  remediationPlan: { priority: number; severity: string; title: string; description: string; affectedPages: string[]; estimatedEffort: string; frequency?: number }[];
  pageBreakdown: { url: string; title: string; score: number; issueCount: number; criticalCount: number; highCount: number; mediumCount: number; lowCount: number }[];
}

// ===== KPMG COLOURS =====
const sevColors: Record<string, string>  = { critical: '#FF3356', high: '#FF8533', medium: '#F0AB00', low: '#0091DA' };
const catLabels: Record<string, string>  = { perceivable: 'Perceivable', operable: 'Operable', understandable: 'Understandable', robust: 'Robust', pdf: 'PDF' };
const compLabels: Record<string, string> = {
  'non-compliant': 'Non-Compliant',
  'partially-compliant': 'Partially Compliant',
  'aa-compliant': 'WCAG AA Compliant',
  'aaa-compliant': 'WCAG AAA Compliant'
};
const compBadge: Record<string, string> = {
  'non-compliant': 'badge-critical',
  'partially-compliant': 'badge-medium',
  'aa-compliant': 'badge-pass',
  'aaa-compliant': 'badge-info'
};
const confColors: Record<string, string> = { high: '#00BA8C', medium: '#F0AB00', low: '#FF8533' };
const statusIcons: Record<string, string>  = { pass: '✔', fail: '✗', error: '⚠', running: '⏳', pending: '⏸', 'needs-review': '?' };
const statusColors: Record<string, string> = { pass: '#00BA8C', fail: '#FF3356', error: '#FF8533', running: '#0091DA', pending: '#5B7198' };

// N/A status display
const wcagStatusConfig: Record<string, { label: string; badgeClass: string; icon: string }> = {
  pass:       { label: 'Pass',       badgeClass: 'badge-pass',   icon: '✔' },
  fail:       { label: 'Fail',       badgeClass: 'badge-critical', icon: '✗' },
  'not-tested': { label: 'N/A',      badgeClass: 'badge-na',     icon: '—' },
};

function ScoreGauge({ score }: { score: number }) {
  const color = score >= 90 ? '#00BA8C' : score >= 75 ? '#0091DA' : score >= 50 ? '#F0AB00' : '#FF3356';
  const circ = 2 * Math.PI * 85;
  const off = circ - (score / 100) * circ;
  return (
    <div className="score-gauge">
      <svg width="200" height="200" viewBox="0 0 200 200">
        <circle cx="100" cy="100" r="85" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="10" />
        <circle cx="100" cy="100" r="85" fill="none" stroke={color} strokeWidth="10" strokeLinecap="round"
          strokeDasharray={circ} strokeDashoffset={off} style={{ transition: 'stroke-dashoffset 1.5s ease' }} />
      </svg>
      <span className="score-value" style={{ background: `linear-gradient(135deg, ${color}, ${color}cc)`, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>{score}</span>
      <span className="score-label">Score</span>
    </div>
  );
}

export default function AuditResultPage() {
  const params = useParams();
  const id = params.id as string;
  const [data, setData] = useState<AuditData | null>(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [severityFilter, setSeverityFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [wcagFilter, setWcagFilter] = useState<'all' | 'fail' | 'pass' | 'not-tested'>('all');
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [exportLoading, setExportLoading] = useState<string | null>(null);
  const [issueView, setIssueView] = useState<'grouped' | 'all'>('grouped');
  const logEndRef = useRef<HTMLDivElement>(null);

  const handleExport = async (format: 'docx' | 'pdf' | 'pptx') => {
    setExportLoading(format);
    try {
      const res = await fetch(`/api/export-report?id=${id}&format=${format}`);
      if (!res.ok) { alert('Export failed'); return; }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url;
      const d = res.headers.get('Content-Disposition')?.match(/filename="(.+?)"/);
      a.download = d ? d[1] : `audit-report.${format}`;
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      URL.revokeObjectURL(url); setShowExportMenu(false);
    } catch { alert('Export failed.'); } finally { setExportLoading(null); }
  };

  const fetchData = useCallback(async () => {
    const res = await fetch(`/api/audit/${id}`);
    if (res.ok) { const d = await res.json(); setData(d); return d.status; }
    return 'error';
  }, [id]);

  useEffect(() => {
    fetchData();
    const interval = setInterval(async () => {
      const status = await fetchData();
      if (status === 'complete' || status === 'error') clearInterval(interval);
    }, 1500);
    return () => clearInterval(interval);
  }, [fetchData]);

  useEffect(() => { logEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [data?.testLog?.length]);

  if (!data) return <div className="container" style={{ paddingTop: 80, textAlign: 'center' }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  // ===== IN-PROGRESS VIEW =====
  if (data.status !== 'complete' && data.status !== 'error') {
    const testedLevels = data.config?.wcagLevels || ['A', 'AA'];
    const levelLabel = testedLevels.includes('AAA') ? 'AAA' : testedLevels.includes('AA') ? 'AA' : 'A';
    return (
      <div className="container" style={{ paddingTop: 44, maxWidth: 820, margin: '0 auto' }}>
        <div className="glass-card animate-glow" style={{ marginBottom: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 14 }}>
            <div className="spinner" style={{ width: 30, height: 30, flexShrink: 0 }} />
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 3 }}>
                <h2 style={{ fontSize: 18, fontWeight: 600, margin: 0 }}>Audit in Progress</h2>
                <span className={`audit-level-chip ${levelLabel.toLowerCase()}`}>
                  {data.config?.standard || 'WCAG 2.2'} — Level {levelLabel}
                </span>
              </div>
              <p style={{ color: 'var(--text-secondary)', margin: 0, fontSize: 13 }}>{data.config?.url}</p>
            </div>
            <div style={{ fontSize: 22, fontWeight: 300, color: 'var(--accent-blue)', letterSpacing: '-0.02em' }}>{data.progress}%</div>
          </div>
          <div className="progress-bar" style={{ marginBottom: 6 }}>
            <div className="progress-fill" style={{ width: `${data.progress}%` }} />
          </div>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: 0 }}>{data.progressMessage}</p>
        </div>

        {data.testLog && data.testLog.length > 0 && (
          <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '10px 14px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <h3 style={{ fontSize: 13, fontWeight: 700, margin: 0 }}>🧪 Live Test Execution</h3>
              <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                {data.testLog.filter(l => l.status === 'pass').length} passed ·{' '}
                {data.testLog.filter(l => l.status === 'fail').length} failed
              </span>
            </div>
            <div style={{ maxHeight: 380, overflowY: 'auto', padding: '6px 0', fontFamily: "'Cascadia Code', 'Fira Code', monospace", fontSize: 11 }}>
              {data.testLog.map((entry, i) => (
                <div key={i} style={{
                  padding: '5px 14px', display: 'flex', alignItems: 'flex-start', gap: 8,
                  background: entry.status === 'running' ? 'rgba(0,145,218,0.05)' : 'transparent',
                  borderLeft: `3px solid ${statusColors[entry.status] || '#5B7198'}`,
                  animation: entry.status === 'running' ? 'pulse 2s ease infinite' : 'none',
                }}>
                  <span style={{ color: statusColors[entry.status], fontSize: 12, flexShrink: 0, width: 14, textAlign: 'center' }}>
                    {statusIcons[entry.status] || '·'}
                  </span>
                  <span style={{
                    color: entry.status === 'running' ? 'var(--accent-blue)' :
                           entry.status === 'fail' ? '#FF3356' :
                           entry.status === 'pass' ? '#00BA8C' : 'var(--text-secondary)',
                    flex: 1, lineHeight: 1.45
                  }}>
                    {entry.message}
                    {entry.wcag && <span style={{ color: 'var(--text-muted)', marginLeft: 6 }}>(WCAG {entry.wcag})</span>}
                  </span>
                </div>
              ))}
              <div ref={logEndRef} />
            </div>
          </div>
        )}
      </div>
    );
  }

  if (data.status === 'error') {
    return (
      <div className="container" style={{ paddingTop: 80, maxWidth: 560, margin: '0 auto', textAlign: 'center' }}>
        <div className="glass-card" style={{ borderColor: 'rgba(232,0,45,0.3)' }}>
          <div style={{ fontSize: 44, marginBottom: 14 }}>❌</div>
          <h2 style={{ fontSize: 20, fontWeight: 600, marginBottom: 8 }}>Audit Failed</h2>
          <p style={{ color: '#FF3356', fontSize: 14 }}>{data.error}</p>
          <a href="/audit" className="btn btn-primary" style={{ marginTop: 20 }}>Try Again</a>
        </div>
      </div>
    );
  }

  // ===== COMPLETE RESULTS =====
  const testedLevel = data.report?.testedLevel || (data.config?.wcagLevels?.includes('AAA') ? 'AAA' : data.config?.wcagLevels?.includes('AA') ? 'AA' : 'A') || 'AA';
  const standard = data.config?.standard || 'WCAG 2.2';

  const filteredIssues = data.issues.filter(i =>
    (severityFilter === 'all' || i.severity === severityFilter) &&
    (categoryFilter === 'all' || i.category === categoryFilter)
  );

  const downloadJson = () => {
    const blob = new Blob([JSON.stringify(data.report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url;
    a.download = `kpmg-accessibility-report-${id}.json`; a.click();
  };

  const tabs = ['overview', 'tests', 'issues', 'wcag-map', 'remediation', 'pages'];
  if (data.report?.journeyResults && data.report.journeyResults.length > 0) tabs.splice(3, 0, 'journeys');

  // WCAG map filtered counts
  const wcagMapEntries = data.report?.wcagMapping || [];
  const wFail = wcagMapEntries.filter(m => m.status === 'fail').length;
  const wPass = wcagMapEntries.filter(m => m.status === 'pass').length;
  const wNA   = wcagMapEntries.filter(m => m.status === 'not-tested').length;

  return (
    <div className="container" style={{ paddingTop: 28, paddingBottom: 80 }}>
      {/* ── Header ── */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
            <h1 className="page-title">Audit Results</h1>
            <span className={`audit-level-chip ${testedLevel.toLowerCase()}`}>
              {standard} · Level {testedLevel}
            </span>
          </div>
          <p className="page-subtitle">{data.config?.url || 'PDF Upload'}</p>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {/* Export dropdown */}
          <div style={{ position: 'relative' }}>
            <button id="export-dropdown-toggle" className="btn btn-secondary btn-sm"
              onClick={() => setShowExportMenu(!showExportMenu)}
              style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <span>📥</span> Download
              <span style={{ fontSize: 9, marginLeft: 2, transform: showExportMenu ? 'rotate(180deg)' : '', transition: 'transform 0.2s' }}>▼</span>
            </button>
            {showExportMenu && (
              <>
                <div style={{ position: 'fixed', inset: 0, zIndex: 49 }} onClick={() => setShowExportMenu(false)} />
                <div className="animate-fade-in" style={{ position: 'absolute', top: 'calc(100% + 6px)', right: 0, background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: 5, minWidth: 210, zIndex: 50, boxShadow: '0 12px 40px rgba(0,0,0,0.5)' }}>
                  <div style={{ padding: '5px 10px', marginBottom: 3 }}><span style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Export Format</span></div>
                  {[{ key: 'docx', icon: '📄', label: 'Word Document', sub: '.docx' }, { key: 'pdf', icon: '📕', label: 'PDF Report', sub: '.pdf' }, { key: 'pptx', icon: '📊', label: 'PowerPoint', sub: '.pptx' }].map(item => (
                    <button key={item.key} onClick={() => handleExport(item.key as 'docx' | 'pdf' | 'pptx')} disabled={!!exportLoading}
                      style={{ display: 'flex', alignItems: 'center', gap: 9, width: '100%', padding: '9px 10px', background: 'transparent', border: 'none', borderRadius: 'var(--radius-sm)', color: 'var(--text-primary)', cursor: exportLoading ? 'not-allowed' : 'pointer', fontSize: 12, fontFamily: 'Open Sans, sans-serif', textAlign: 'left', transition: 'background 0.2s' }}
                      onMouseEnter={e => (e.currentTarget.style.background = 'var(--bg-card-hover)')}
                      onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                      <span style={{ fontSize: 18 }}>{item.icon}</span>
                      <div><div style={{ fontWeight: 600 }}>{item.label}</div><div style={{ fontSize: 10, color: 'var(--text-muted)' }}>{item.sub}</div></div>
                      {exportLoading === item.key && <div className="spinner" style={{ width: 16, height: 16, marginLeft: 'auto', borderWidth: 2 }} />}
                    </button>
                  ))}
                  <div style={{ height: 1, background: 'var(--border)', margin: '3px 0' }} />
                  <button onClick={() => { downloadJson(); setShowExportMenu(false); }}
                    style={{ display: 'flex', alignItems: 'center', gap: 9, width: '100%', padding: '9px 10px', background: 'transparent', border: 'none', borderRadius: 'var(--radius-sm)', color: 'var(--text-primary)', cursor: 'pointer', fontSize: 12, fontFamily: 'Open Sans, sans-serif', transition: 'background 0.2s' }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'var(--bg-card-hover)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                    <span style={{ fontSize: 18 }}>🔧</span><div><div style={{ fontWeight: 600 }}>Raw JSON</div><div style={{ fontSize: 10, color: 'var(--text-muted)' }}>Developer format</div></div>
                  </button>
                </div>
              </>
            )}
          </div>
          <a href={`/audit/${id}/report`} className="btn-report" aria-label="View Final Delivery Report">
            📋 Final Report
          </a>
          <a href="/audit" className="btn btn-primary btn-sm">+ New Audit</a>
        </div>
      </div>

      {/* ── Score + Summary Cards ── */}
      <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: 20, marginBottom: 20 }}>
        <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          <ScoreGauge score={data.score.overall} />
          <div className={`badge ${compBadge[data.score.complianceLevel] || 'badge-medium'}`}>
            {compLabels[data.score.complianceLevel] || data.score.complianceLevel}
          </div>
          <div className={`audit-level-chip ${testedLevel.toLowerCase()}`} style={{ marginTop: 2 }}>
            Level {testedLevel} Tested
          </div>
        </div>
        <div>
          {/* Issue severity breakdown */}
          <div className="grid-4" style={{ marginBottom: 14 }}>
            {(['critical', 'high', 'medium', 'low'] as const).map(sev => (
              <div key={sev} className="stat-card">
                <div className="stat-value" style={{ color: sevColors[sev] }}>{data.score.issueBySeverity[sev]}</div>
                <div className="stat-label" style={{ textTransform: 'capitalize' }}>{sev}</div>
              </div>
            ))}
          </div>
          {/* Test stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 14 }}>
            <div className="stat-card" style={{ textAlign: 'center', padding: 10, borderLeft: '3px solid var(--accent-blue)' }}>
              <div style={{ fontSize: 20, fontWeight: 300, color: 'var(--accent-blue)' }}>{data.score.testsRun}</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Tests Run</div>
            </div>
            <div className="stat-card" style={{ textAlign: 'center', padding: 10, borderLeft: '3px solid #00BA8C' }}>
              <div style={{ fontSize: 20, fontWeight: 300, color: '#00BA8C' }}>{data.score.testsPassed}</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Passed</div>
            </div>
            <div className="stat-card" style={{ textAlign: 'center', padding: 10, borderLeft: '3px solid #FF3356' }}>
              <div style={{ fontSize: 20, fontWeight: 300, color: '#FF3356' }}>{data.score.testsFailed}</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Failed</div>
            </div>
          </div>
          {/* Category scores */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 8 }}>
            {Object.entries(data.score.categoryScores).map(([cat, score]) => (
              <div key={cat} className="stat-card" style={{ textAlign: 'center', padding: 10 }}>
                <div style={{ fontSize: 17, fontWeight: 300, color: (score as number) >= 75 ? '#00BA8C' : (score as number) >= 50 ? '#F0AB00' : '#FF3356', letterSpacing: '-0.02em' }}>{score as number}</div>
                <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>{catLabels[cat] || cat}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Page Coverage (fixed) ── */}
      {data.crawlCoverage && (
        <div className="glass-card animate-fade-in" style={{ marginBottom: 20, padding: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, margin: 0 }}>📊 Page Coverage</h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                {data.crawlCoverage.pagesAudited} of {data.crawlCoverage.totalPagesFound} pages audited
              </span>
              <span style={{
                fontSize: 18, fontWeight: 300, letterSpacing: '-0.02em',
                color: data.crawlCoverage.coveragePercent >= 80 ? '#00BA8C' :
                       data.crawlCoverage.coveragePercent >= 50 ? '#F0AB00' : '#FF3356'
              }}>
                {data.crawlCoverage.coveragePercent}%
              </span>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginBottom: 10 }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 18, fontWeight: 300, color: 'var(--accent-blue)' }}>{data.crawlCoverage.totalPagesFound}</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Discovered</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 18, fontWeight: 300, color: '#00BA8C' }}>{data.crawlCoverage.pagesAudited}</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Audited</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 18, fontWeight: 300, color: '#FF8533' }}>{data.crawlCoverage.pagesSkipped}</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Skipped</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 18, fontWeight: 300 }}>{data.score.uniqueIssues ?? '—'}</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Unique Issues</div>
            </div>
          </div>
          <div className="coverage-bar">
            <div style={{
              height: '100%', borderRadius: 'var(--radius-full)', transition: 'width 1s ease',
              width: `${data.crawlCoverage.coveragePercent}%`,
              background: data.crawlCoverage.coveragePercent >= 80 ? '#00BA8C' :
                          data.crawlCoverage.coveragePercent >= 50 ? '#F0AB00' : '#FF3356'
            }} />
          </div>
          {data.crawlCoverage.coveragePercent < 100 && (
            <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 6 }}>
              ℹ️ Coverage is limited by the configured max page setting. Increase "Max Pages" for broader analysis.
            </p>
          )}
        </div>
      )}

      {/* ── Tab Bar ── */}
      <div className="tabs" style={{ marginBottom: 20 }}>
        {tabs.map(t => (
          <button key={t} className={`tab ${activeTab === t ? 'active' : ''}`} onClick={() => setActiveTab(t)} style={{ textTransform: 'capitalize' }}>
            {t === 'wcag-map' ? `WCAG Map` : t === 'journeys' ? '🚶 Journeys' : t === 'tests' ? '🧪 Tests' : t}
          </button>
        ))}
      </div>

      {/* ══════════════════════════════════════════════════════
           OVERVIEW TAB
         ══════════════════════════════════════════════════════ */}
      {activeTab === 'overview' && data.report && (
        <div className="animate-fade-in">
          <div className="glass-card" style={{ marginBottom: 20 }}>
            <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 10 }}>Executive Summary</h3>
            <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.75, whiteSpace: 'pre-line' }}>{data.report.executiveSummary}</p>
          </div>

          {data.report.topCritical && data.report.topCritical.length > 0 && (
            <div className="glass-card" style={{ marginBottom: 20, borderLeft: '3px solid #FF3356' }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 14 }}>🔥 Top Critical Issues</h3>
              {data.report.topCritical.map((g, idx) => (
                <div key={g.issueKey} style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: '11px 0', borderBottom: idx < data.report!.topCritical!.length - 1 ? '1px solid var(--border)' : 'none' }}>
                  <span style={{ background: sevColors[g.severity], color: 'white', borderRadius: '50%', width: 26, height: 26, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, flexShrink: 0 }}>{idx + 1}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                      <span style={{ fontWeight: 700, fontSize: 13 }}>{g.title}</span>
                      <span className={`badge badge-${g.severity}`}>{g.severity}</span>
                      <span className="badge badge-na" style={{ marginLeft: 2 }}>WCAG {g.wcagCriterion}</span>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 3 }}>{g.description.substring(0, 150)}</div>
                    <div style={{ display: 'flex', gap: 10, fontSize: 11, color: 'var(--text-muted)' }}>
                      <span>📄 {g.affectedPages.length} page{g.affectedPages.length > 1 ? 's' : ''}</span>
                      <span>🔄 {g.occurrenceCount}×</span>
                      <span>📊 {g.frequency}% frequency</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {data.report.journeyResults && data.report.journeyResults.length > 0 && (
            <div className="glass-card" style={{ marginBottom: 20 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 14 }}>🚶 User Journey Tests</h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: 10 }}>
                {data.report.journeyResults.map(j => (
                  <div key={j.journeyName} style={{ padding: '12px 14px', borderRadius: 'var(--radius-md)', background: j.passed ? 'rgba(0,186,140,0.07)' : 'rgba(232,0,45,0.07)', border: `1px solid ${j.passed ? 'rgba(0,186,140,0.2)' : 'rgba(232,0,45,0.2)'}` }}>
                    <div style={{ fontSize: 18, marginBottom: 5 }}>{j.passed ? '✅' : '❌'}</div>
                    <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 2 }}>{j.journeyName}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{j.steps.filter(s => s.passed).length}/{j.steps.length} steps passed</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════
           TESTS TAB
         ══════════════════════════════════════════════════════ */}
      {activeTab === 'tests' && (
        <div className="animate-fade-in">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
            {[
              { label: 'Total Tests', val: data.testResults.length, color: 'var(--accent-blue)' },
              { label: 'Passed', val: data.testResults.filter(r => r.status === 'pass').length, color: '#00BA8C' },
              { label: 'Failed', val: data.testResults.filter(r => r.status === 'fail').length, color: '#FF3356' },
              { label: 'Errors', val: data.testResults.filter(r => r.status === 'error').length, color: '#FF8533' },
            ].map((s, i) => (
              <div key={i} className="stat-card" style={{ textAlign: 'center', borderTop: `3px solid ${s.color}` }}>
                <div className="stat-value" style={{ color: s.color }}>{s.val}</div>
                <div className="stat-label">{s.label}</div>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {data.testResults.map((tr, idx) => (
              <div key={idx} className="glass-card" style={{
                padding: '13px 15px', display: 'flex', alignItems: 'flex-start', gap: 12,
                borderLeft: `3px solid ${statusColors[tr.status] || '#5B7198'}`,
                background: tr.status === 'pass' ? 'rgba(0,186,140,0.03)' : tr.status === 'fail' ? 'rgba(232,0,45,0.03)' : undefined,
              }}>
                <span style={{ fontSize: 18, flexShrink: 0, marginTop: 2 }}>
                  {tr.status === 'pass' ? '✅' : tr.status === 'fail' ? '❌' : '⚠️'}
                </span>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4, flexWrap: 'wrap' }}>
                    <span style={{ fontWeight: 700, fontSize: 13 }}>{tr.testName}</span>
                    <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 99, background: 'rgba(0,145,218,0.1)', color: '#0091DA', fontWeight: 700 }}>{tr.testId}</span>
                    <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>WCAG {tr.wcagCriterion}</span>
                    <span className={`badge badge-level-${tr.wcagLevel.toLowerCase()}`}>{tr.wcagLevel}</span>
                    <span className={`badge ${tr.status === 'pass' ? 'badge-pass' : `badge-${tr.severity}`}`} style={{ marginLeft: 'auto' }}>
                      {tr.status.toUpperCase()}
                    </span>
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 5 }}>{tr.evidence.summary}</div>
                  <div style={{ display: 'flex', gap: 10, fontSize: 11, color: 'var(--text-muted)', flexWrap: 'wrap' }}>
                    <span>🔍 {tr.evidence.elementsChecked} checked</span>
                    <span style={{ color: tr.evidence.elementsFailed > 0 ? '#FF3356' : '#00BA8C' }}>
                      {tr.evidence.elementsFailed > 0 ? `✗ ${tr.evidence.elementsFailed} failed` : '✓ All passed'}
                    </span>
                    <span>⏱ {tr.executionTime}ms</span>
                    <span style={{ color: confColors[tr.confidence] }}>🎯 {tr.confidence}</span>
                  </div>
                  {tr.evidence.details.length > 0 && tr.status === 'fail' && (
                    <details style={{ marginTop: 7 }}>
                      <summary style={{ cursor: 'pointer', fontSize: 11, color: 'var(--accent-blue)', fontWeight: 600 }}>
                        View Evidence ({tr.evidence.details.length} items)
                      </summary>
                      <div style={{ marginTop: 7, padding: 10, background: 'rgba(0,0,0,0.2)', borderRadius: 'var(--radius-sm)', fontFamily: "'Cascadia Code', monospace", fontSize: 10, lineHeight: 1.6, maxHeight: 180, overflowY: 'auto' }}>
                        {tr.evidence.details.map((d, i) => (
                          <div key={i} style={{ color: d.startsWith('✔') ? '#00BA8C' : d.startsWith('✗') || d.startsWith('⚠') || d.startsWith('❌') ? '#FF3356' : 'var(--text-secondary)' }}>{d}</div>
                        ))}
                      </div>
                    </details>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════
           ISSUES TAB
         ══════════════════════════════════════════════════════ */}
      {activeTab === 'issues' && (
        <div className="animate-fade-in">
          <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap', alignItems: 'center' }}>
            <div style={{ display: 'flex', borderRadius: 'var(--radius-sm)', overflow: 'hidden', border: '1px solid var(--border)' }}>
              <button onClick={() => setIssueView('grouped')} style={{ padding: '6px 13px', fontSize: 12, fontWeight: 700, border: 'none', cursor: 'pointer', fontFamily: 'Open Sans', background: issueView === 'grouped' ? 'var(--accent-blue)' : 'transparent', color: issueView === 'grouped' ? 'white' : 'var(--text-muted)' }}>Grouped</button>
              <button onClick={() => setIssueView('all')}     style={{ padding: '6px 13px', fontSize: 12, fontWeight: 700, border: 'none', cursor: 'pointer', fontFamily: 'Open Sans', background: issueView === 'all' ? 'var(--accent-blue)' : 'transparent', color: issueView === 'all' ? 'white' : 'var(--text-muted)' }}>All</button>
            </div>
            <select className="input-field" style={{ width: 'auto' }} value={severityFilter} onChange={e => setSeverityFilter(e.target.value)}>
              <option value="all">All Severities</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
            <select className="input-field" style={{ width: 'auto' }} value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)}>
              <option value="all">All Categories</option>
              {Object.entries(catLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>

          {issueView === 'grouped' && data.report?.groupedIssues && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
              {data.report.groupedIssues
                .filter(g => (severityFilter === 'all' || g.severity === severityFilter) && (categoryFilter === 'all' || g.category === categoryFilter))
                .map(g => (
                  <div key={g.issueKey} className="issue-card">
                    <div className="issue-card-header">
                      <span className="issue-card-title">{g.title}</span>
                      <div style={{ display: 'flex', gap: 5, alignItems: 'center', flexShrink: 0 }}>
                        {g.occurrenceCount > 1 && <span style={{ background: 'rgba(123,79,187,0.12)', color: '#A78BFA', fontSize: 10, padding: '2px 7px', borderRadius: 99, fontWeight: 700 }}>{g.occurrenceCount}× · {g.affectedPages.length} page{g.affectedPages.length > 1 ? 's' : ''}</span>}
                        <span className={`badge badge-${g.severity}`}>{g.severity}</span>
                      </div>
                    </div>
                    <div className="issue-card-desc">{g.description.substring(0, 180)}</div>
                    <div className="issue-card-meta">
                      <span className="issue-card-tag">📋 {g.wcagCriterion} {g.wcagName}</span>
                      <span className={`badge badge-level-${g.wcagLevel.toLowerCase()}`}>{g.wcagLevel}</span>
                      <span className="issue-card-tag">📂 {catLabels[g.category] || g.category}</span>
                      <span className="issue-card-tag" style={{ color: confColors[g.confidence] }}>🎯 {g.confidence} confidence</span>
                      {g.frequency > 50 && <span className="badge badge-high">Widespread {g.frequency}%</span>}
                    </div>
                  </div>
                ))}
            </div>
          )}

          {issueView === 'all' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
              {filteredIssues.map(issue => (
                <div key={issue.id} className="issue-card" onClick={() => setSelectedIssue(issue)}>
                  <div className="issue-card-header">
                    <span className="issue-card-title">{issue.title}</span>
                    <span className={`badge badge-${issue.severity}`}>{issue.severity}</span>
                  </div>
                  <div className="issue-card-desc">{issue.description.substring(0, 180)}</div>
                  <div className="issue-card-meta">
                    <span className="issue-card-tag">📋 {issue.wcagCriterion}</span>
                    <span className={`badge badge-level-${issue.wcagLevel.toLowerCase()}`}>{issue.wcagLevel}</span>
                    <span className="issue-card-tag">🔧 {issue.source}</span>
                    {issue.confidence && <span className="issue-card-tag" style={{ color: confColors[issue.confidence] }}>🎯 {issue.confidence}</span>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════
           JOURNEYS TAB
         ══════════════════════════════════════════════════════ */}
      {activeTab === 'journeys' && data.report?.journeyResults && (
        <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {data.report.journeyResults.map(j => (
            <div key={j.journeyName} className="glass-card">
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
                <span style={{ fontSize: 26 }}>{j.passed ? '✅' : '❌'}</span>
                <div><h3 style={{ fontSize: 15, fontWeight: 700, margin: 0 }}>{j.journeyName}</h3><p style={{ fontSize: 12, color: 'var(--text-muted)', margin: 0 }}>{j.description}</p></div>
                <span className={`badge ${j.passed ? 'badge-pass' : 'badge-critical'}`} style={{ marginLeft: 'auto' }}>{j.passed ? 'PASSED' : 'FAILED'}</span>
              </div>
              {j.steps.map((s, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 9, padding: '9px 11px', marginBottom: 5, background: s.passed ? 'rgba(0,186,140,0.05)' : 'rgba(232,0,45,0.05)', borderRadius: 'var(--radius-sm)', border: `1px solid ${s.passed ? 'rgba(0,186,140,0.15)' : 'rgba(232,0,45,0.15)'}` }}>
                  <span style={{ fontSize: 14 }}>{s.passed ? '✅' : '❌'}</span>
                  <div><div style={{ fontWeight: 600, fontSize: 12 }}>{s.name}</div><div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>{s.action}</div>{s.issue && <div style={{ fontSize: 11, color: '#FF3356', marginTop: 3 }}>⚠ {s.issue}</div>}</div>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════
           WCAG MAP TAB — with N/A support
         ══════════════════════════════════════════════════════ */}
      {activeTab === 'wcag-map' && data.report && (
        <div className="animate-fade-in">
          {/* Filter + Stats row */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14, flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', gap: 6 }}>
              {(['all', 'fail', 'pass', 'not-tested'] as const).map(f => (
                <button key={f} onClick={() => setWcagFilter(f)} style={{
                  padding: '5px 12px', fontSize: 11, fontWeight: 700, border: `1px solid ${wcagFilter === f ? 'var(--accent-blue)' : 'var(--border)'}`,
                  borderRadius: 99, cursor: 'pointer', fontFamily: 'Open Sans',
                  background: wcagFilter === f ? 'rgba(0,145,218,0.12)' : 'transparent',
                  color: wcagFilter === f ? 'var(--accent-blue)' : 'var(--text-muted)',
                  transition: 'var(--transition)'
                }}>
                  {f === 'not-tested' ? 'N/A' : f.charAt(0).toUpperCase() + f.slice(1)}
                  {' '}({f === 'all' ? wcagMapEntries.length : f === 'fail' ? wFail : f === 'pass' ? wPass : wNA})
                </button>
              ))}
            </div>
            <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, fontSize: 11, color: 'var(--text-muted)' }}>
              <span>📋 Audited against <strong style={{ color: 'var(--text-primary)' }}>{standard} Level {testedLevel}</strong></span>
            </div>
          </div>

          <div className="glass-card" style={{ overflow: 'auto', padding: 0 }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Criterion</th>
                  <th>Name</th>
                  <th>Level</th>
                  <th>Issues</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {wcagMapEntries
                  .filter(m => wcagFilter === 'all' || m.status === wcagFilter)
                  .map(m => {
                    const cfg = wcagStatusConfig[m.status] || wcagStatusConfig['not-tested'];
                    return (
                      <tr key={m.criterion}>
                        <td><span style={{ fontWeight: 700, fontFamily: "'Cascadia Code', monospace", fontSize: 12 }}>{m.criterion}</span></td>
                        <td>{m.name}</td>
                        <td><span className={`badge badge-level-${m.level.toLowerCase()}`}>{m.level}</span></td>
                        <td>
                          {m.status === 'not-tested'
                            ? <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>—</span>
                            : <span style={{ fontWeight: 700, color: m.issueCount > 0 ? '#FF3356' : '#00BA8C' }}>{m.issueCount}</span>
                          }
                        </td>
                        <td>
                          <span className={`badge ${cfg.badgeClass}`} title={m.status === 'not-tested' ? 'This criterion was not applicable to the audited content (e.g. no video → captions N/A)' : ''}>
                            {cfg.icon} {cfg.label}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>

          {/* N/A explanation */}
          <div className="kpmg-banner" style={{ marginTop: 14, marginBottom: 0 }}>
            <span className="kpmg-banner-icon">ℹ️</span>
            <span><strong>N/A (Not Applicable)</strong> — These criteria were identified as not applicable to the audited content. For example: captions criteria when no video is present, or error prevention when no forms exist. This is not a failure.</span>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════
           REMEDIATION TAB
         ══════════════════════════════════════════════════════ */}
      {activeTab === 'remediation' && data.report && (
        <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {data.report.remediationPlan.map(step => (
            <div key={step.priority} className="glass-card" style={{ borderLeft: `3px solid ${sevColors[step.severity]}` }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 11, marginBottom: 7 }}>
                <span style={{ background: sevColors[step.severity], color: 'white', borderRadius: '50%', width: 26, height: 26, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700 }}>{step.priority}</span>
                <span style={{ fontWeight: 700, fontSize: 14 }}>{step.title}</span>
                <span className={`badge badge-${step.severity}`} style={{ marginLeft: 'auto' }}>{step.severity}</span>
              </div>
              <p style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{step.description}</p>
              <div style={{ marginTop: 7, fontSize: 11, color: 'var(--text-muted)', display: 'flex', gap: 14 }}>
                <span>💪 Effort: {step.estimatedEffort}</span>
                <span>📄 {step.affectedPages.length} page{step.affectedPages.length > 1 ? 's' : ''}</span>
                {step.frequency && <span>📊 {step.frequency}% of pages</span>}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════
           PAGES TAB
         ══════════════════════════════════════════════════════ */}
      {activeTab === 'pages' && data.report && (
        <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {data.report.pageBreakdown.map(page => (
            <div key={page.url} className="glass-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{page.title}</div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 7, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{page.url}</div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {page.criticalCount > 0 && <span className="badge badge-critical">{page.criticalCount} Critical</span>}
                  {page.highCount > 0     && <span className="badge badge-high">{page.highCount} High</span>}
                  {page.mediumCount > 0   && <span className="badge badge-medium">{page.mediumCount} Medium</span>}
                  {page.lowCount > 0      && <span className="badge badge-low">{page.lowCount} Low</span>}
                  {page.issueCount === 0  && <span className="badge badge-pass">No Issues</span>}
                </div>
              </div>
              <div style={{
                width: 54, height: 54, borderRadius: '50%', flexShrink: 0, marginLeft: 16,
                border: `3px solid ${page.score >= 75 ? '#00BA8C' : page.score >= 50 ? '#F0AB00' : '#FF3356'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontWeight: 300, fontSize: 17, letterSpacing: '-0.02em',
                color: page.score >= 75 ? '#00BA8C' : page.score >= 50 ? '#F0AB00' : '#FF3356'
              }}>
                {page.score}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════
           ISSUE MODAL
         ══════════════════════════════════════════════════════ */}
      {selectedIssue && (
        <div className="modal-overlay" onClick={() => setSelectedIssue(null)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18 }}>
              <div>
                <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 5 }}>{selectedIssue.title}</h3>
                <div style={{ display: 'flex', gap: 6 }}>
                  <span className={`badge badge-${selectedIssue.severity}`}>{selectedIssue.severity}</span>
                  <span className={`badge badge-level-${selectedIssue.wcagLevel.toLowerCase()}`}>{selectedIssue.wcagLevel}</span>
                </div>
              </div>
              <button onClick={() => setSelectedIssue(null)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: 18, cursor: 'pointer' }}>✕</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div><strong style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Description</strong><p style={{ fontSize: 13, lineHeight: 1.65, marginTop: 5 }}>{selectedIssue.description}</p></div>
              <div><strong style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>WCAG Criterion</strong><p style={{ fontSize: 13, marginTop: 5 }}>{selectedIssue.wcagCriterion} — {selectedIssue.wcagName} (Level {selectedIssue.wcagLevel})</p></div>
              <div><strong style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Impact</strong><p style={{ fontSize: 13, marginTop: 5, color: 'var(--text-secondary)' }}>{selectedIssue.impact}</p></div>
              {selectedIssue.elementHtml && <div><strong style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Element</strong><pre className="code-block" style={{ marginTop: 5 }}>{selectedIssue.elementHtml}</pre></div>}
              <div><strong style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Recommendation</strong><p style={{ fontSize: 13, marginTop: 5, color: '#00BA8C' }}>{selectedIssue.recommendation}</p></div>
              {selectedIssue.codeFix && <div><strong style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Code Fix</strong><pre className="code-block" style={{ marginTop: 5 }}>{selectedIssue.codeFix}</pre></div>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
